# 🧰 Kit Sentimen Ritel — Panduan & Prompt Pack untuk Trader Saham IDX

> **Alat bantu riset psikologi & sentimen pasar ritel di forum Stockbit.**  
> *Bisa dipakai dengan hasil dari **Extension Scraper Otomatis** (PC/Laptop) ATAU cukup **Copy-Paste Manual** postingan dari aplikasi Stockbit di HP / Browser.*

---
🎁 **EDISI PUBLIK GRATIS — KOMUNITAS TRADER RITEL INDONESIA**  
*Diterbitkan resmi oleh **Lotmetrik Research** (Kanal Resmi Telegram: `t.me/lotmetrik`).*  
*Status: 100% Gratis & Terbuka untuk Edukasi & Riset Mandiri Trader Saham IDX (Bebas Biaya).*  
*Dokumen ini memuat formula prompt AI, kamus slang pasar modal, dan panduan audit psikologi pasar. Bebas dibagikan dan digunakan oleh komunitas trader ritel agar tidak mudah terjebak aksi pom-pom di forum bursa. Pembaruan berkala formula prompt dan kamus slang IDX dapat diakses gratis di channel Telegram.*
---

## 🚀 Cara Pakai (Alur 30 Detik)

```
┌─────────────────────────────────┐      ┌───────────────────────────────┐      ┌──────────────────────────────────┐
│   1. Ambil Obrolan Stream       │      │   2. Pilih Salah Satu Prompt  │      │   3. Tempel ke ChatGPT / Claude  │
│   (Via Scraper atau Copas HP)   │ ───► │   (Sesuai kebutuhan analisamu)│ ───► │   (Langsung keluar rangkuman)    │
└─────────────────────────────────┘      └───────────────────────────────┘      └──────────────────────────────────┘
```

1. **Ambil Data Stream:**
   * **Cara Otomatis:** Buka `stockbit.com/symbol/EMITEN` → klik tombol **Mulai Scrape** di panel extension → klik **📋 Salin** atau klik **Buka AI 🚀** (langsung otomatis salin & buka ChatGPT).
   * **Cara Manual (HP/Browser):** Buka tab Stream di aplikasi Stockbit → blok & salin beberapa postingan obrolan terbaru.
2. **Pilih Prompt di bawah** → Salin salah satu prompt (Prompt 1, 2, 3, atau 4).
3. **Tempel ke AI:** Buka ChatGPT, Claude, atau Gemini → Paste prompt + data stream → Kirim!

---

## 📖 Kamus Slang Ritel IDX (Sudah Tertanam di Prompt)

| Istilah | Arti / Konteks Ritel | Klasifikasi Sentimen |
|---|---|---|
| **ARA / araa ndar / arakan / terbang** | Minta bandar dorong ke Auto Reject Atas | 🟢 **BULLISH** |
| **gas / roket 🚀 / cabut / haka / jemput** | Dorongan beli / optimisme naik kencang | 🟢 **BULLISH** |
| **loyo / berat / nyangkut / dump / sisir** | Tekanan jual / frustrasi harga tertahan | 🔴 **BEARISH** |
| *"bandarnya jujur", "welcome apestor", "pagarin"* | **Sarkasme / Sindiran kekecewaan** | 🔴 **BEARISH (Sarkas)** |
| **pom-pom / kompor / buzzer / exit liquidity** | Ajakan beli mencurigakan / umpan distribusi | ⚠️ **RED FLAG** |
| **RT $XXX / tag rame-rame / DM screener / join grup** | Promosi berbayar / spam non-organik | ⚪ **NOISE / PROMO** |

---

## 🅰️ Prompt 1 — Rangkuman Mood & Sentimen 30 Detik *(Paling Sering Dipakai)*

Salin teks di bawah ini ke AI:

```text
Kamu adalah analis sentimen ritel profesional untuk saham Bursa Efek Indonesia (IDX). 
Di bawah ini terdapat kumpulan obrolan stream forum Stockbit untuk 1 emiten.

Gunakan kamus sentimen ritel:
- Bullish: ARA, araa ndar, gas, roket, cabut, haka, kejemput, to the moon, cicil.
- Bearish: loyo, berat, nyangkut, dump, sisiran, boncos, cutloss, ambles.
- Sarkasme (hitung sebagai Bearish): "bandarnya baik/jujur", "welcome apestor", "pagarin ndar", "makasih bandar".
- Noise/Promo: Tag >2 emiten berbeda, ajakan DM screener, link grup VIP, spam berulang.

Tugasmu merangkum secara PADAT & TEGAS:
1. Verdict Sentimen: % Bullish vs % Bearish vs % Noise/Promo + Tingkat Keyakinan (Rendah/Sedang/Tinggi).
2. Pergeseran Emosi: Bagaimana tren mood dari jam-jam awal ke jam-jam akhir (apakah optimisme mereda atau kepanikan meningkat?).
3. 3 Topik Utama: Apa rumor, sentimen laporan keuangan, atau aksi korporasi yang paling banyak disebut?
4. 🚩 Sinyal Bahaya (Red Flag): Apakah ada indikasi euforia berlebihan atau kepanikan masal?

STREAM DATA:
<TEMPEL HASIL COPY STREAM DI SINI>
```

### 📌 Contoh Output Nyata dari AI (Prompt 1)
```text
📊 VERDICT SENTIMEN ($ANTM - Stream 1 Hari)
• Sentimen: 68% Bullish | 18% Bearish | 14% Noise/Promo
• Keyakinan Analis AI: TINGGI (Sampel 85 obrolan organik)

⏱️ PERGESERAN EMOSI
• Sesi Pagi (09:00 - 11:30): Euforia tinggi ("gass jemput 3000", "araa ndar").
• Sesi Siang (13:30 - 15:30): Mulai melandai dan defensif ("kok berat ya di 2950", "haki mulai tebel").

💬 3 TOPIK UTAMA OBROLAN
1. Kenaikan harga nikel & emas dunia semalam.
2. Spekulasi dividen yield kuartal ini.
3. Ritel memperdebatkan apakah asing sedang net buy atau jualan diam-diam.

🚩 SINYAL BAHAYA (RED FLAG)
• Terdapat 4 akun spam promosi grup VIP scalping.
• Euforia pagi sempat menyentuh level FOMO (banyak ajakan HAKA tanpa kalkulasi support).
```

---

## 🅱️ Prompt 2 — Filter Akun Pom-pom & Buzzer Kompor

Salin teks di bawah ini ke AI:

```text
Dari kumpulan data stream Stockbit di bawah, lakukan audit khusus untuk MENDETEKSI AKUN POM-POM / BUZZER / NOISE.

Kriteria Akun Mencurigakan:
- Mengajak beli dengan kata-kata bombastis tanpa analisa fundamental/teknikal.
- Menempelkan (tag) banyak cashtag saham lain sekaligus agar dilihat banyak orang.
- Mengajak masuk grup Telegram/WA berbayar atau meminta DM.
- Memposting kalimat yang sama berulang-ulang dalam selang waktu singkat.

Keluarkan hasil terstruktur:
1. Daftar Akun Mencurigakan (+ kutipan bukti kalimatnya).
2. Estimasi Noise: Berapa % postingan yang murni kompor vs obrolan trader riil.
3. Mood Organik Murni: Jika semua akun kompor dibuang, bagaimana sentimen trader aslinya?

STREAM DATA:
<TEMPEL HASIL COPY STREAM DI SINI>
```

### 📌 Contoh Output Nyata dari AI (Prompt 2)
```text
🚨 AUDIT BUZZER & POM-POM STREAM
1. Akun Terindikasi Kompor:
   • @trader_cuan99: "ARAAKAN NDAR $ANTM $BUMI $DEWA GASSS JANGAN KETINGGALAN!!" (Spam 5x dalam 20 menit).
   • @screener_sakti: "Yg mau bocoran saham ARA besok langsung DM ya" (Promo grup).

2. Rasio Noise: Sekitar 22% dari total post hari ini adalah spam/kompor.
3. Mood Organik: Setelah noise dibuang, sentimen riil hanya 48% Bullish dan 52% Netral/Waspada.
```

---

## 🅲 Prompt 3 — Deteksi Percepatan Obrolan (Velocity Multi-Hari)

Salin teks di bawah ini ke AI:

```text
Berikut data stream forum Stockbit untuk 1 emiten selama 2-3 hari bursa.
Fokus utamamu adalah menganalisis PERCEPATAN OBROLAN (VELOCITY).

Analisis:
1. Volume Mention: Bandingkan kepadatan post hari ini dibanding kemarin (Meningkat drastis / Stabil / Menurun).
2. Status Obrolan: Apakah saham ini sedang "Memanas" (Hyped) atau "Mendingin" (Minat hilang)?
3. Pola Bahaya: Apakah volume obrolan melonjak tajam NAMUN diiringi keluhan "nyangkut/berat"? (Tanda potensi distribusi bandar ke ritel).

STREAM DATA:
<TEMPEL HASIL COPY STREAM DI SINI>
```

---

## 🅳 Prompt 4 — Analisis Divergence (Mood Ritel vs Realita Harga)

Salin teks di bawah ini ke AI:

```text
Ini adalah data stream Stockbit untuk 1 emiten.
Data Harga Penutupan Hari Ini: <ISI MANUAL, Contoh: Rp1.450 (-2.5%), High 1.510, Low 1.440>

Tugasmu mencari DIVERGENCE (Ketidaksesuaian Psikologi Ritel vs Grafik Harga):
1. Pola A: Ritel sangat Bullish/Euforia TAPI harga stagnan atau turun -> Potensi Ritel Jadi Exit Liquidity.
2. Pola B: Ritel sangat Pesimis/Frustrasi TAPI harga bertahan kokoh di area Support -> Potensi Akumulasi Diam-diam.
3. Pola C: Ritel & Harga Searah -> Tren sehat atau sedang di fase klimaks.

Simpulkan dalam 1 paragraf: Apa risiko terbesar bagi trader yang ingin entry saat ini?

STREAM DATA:
<TEMPEL HASIL COPY STREAM DI SINI>
```

---

## ⚙️ Formula Custom Instructions (Pasang 1x di ChatGPT, Pakai Selamanya)

*Bosan bolak-balik copas prompt panjang? Kamu bisa mengubah ChatGPT menjadi **Asisten Analis Sentimen IDX Permanen**.*

### Cara Pasang di ChatGPT:
1. Buka ChatGPT di web atau aplikasi HP.
2. Klik foto profilmu (kiri bawah di web / kanan atas di HP) → pilih **Settings** → **Custom Instructions** (atau buat *Custom GPT*).
3. Di kotak *"How would you like ChatGPT to respond?"*, tempel formula di bawah ini:

```text
Kamu adalah analis sentimen ritel pasar modal Indonesia (IDX) independen dari Lotmetrik. 
Setiap kali saya mengirimkan teks kumpulan obrolan forum saham (format [tgl jam] user: teks), tugas utamamu otomatis:
1. Saring spam: Pisahkan akun buzzer/kompor yang mempromosikan grup berbayar, tag masal >2 saham, atau ajakan HAKA tanpa dasar.
2. Terapkan kamus slang & sarkasme IDX:
   - "bandarnya jujur/baik", "welcome apestor", "pagarin ndar", "makasih bandar" = SARKASME (Bearish Keras).
   - "loyo", "berat", "nyangkut", "dump", "boncos", "bid ompong", "rompi oren" = KELUHAN/BEARISH.
   - "ara", "gas", "roket", "cabut", "haka", "cuan", "jemput" = OPTIMISME/BULLISH (audit jika dari kompor).
3. Berikan output instan:
   - 📊 Verdict Skor: % Bullish Organik vs % Bearish vs % Noise Spam
   - ⏱️ Pergeseran Mood: Perbedaan emosi pagi vs siang
   - 🚩 Red Flag: Apakah ada indikasi euforia semu saat harga macet (Divergence / Exit Liquidity)
   - ⚠️ Daftar Akun Terindikasi Kompor
Format selalu padat, objektif, tanpa basa-basi, dan berbasis data obrolan yang saya kirim.
```
4. Klik **Save**. Mulai sekarang, setiap kali kamu lempar hasil salinan stream dari Stockbit, ChatGPT akan **langsung otomatis mengeluarkan analisis lengkap** tanpa perlu kamu ketik prompt lagi!

---

## 📚 Studi Kasus Retrospektif Nyata Bursa IDX

### Kasus 1: $GOTO — Jebakan "Rebound Semu" Sebelum ARB Berjilid
* **Konteks Pasar:** Saat harga mendekati level psikologis Rp100, forum dipenuhi teriakan "Serok bawah", "Gak mungkin jebol gocap", dan akun-akun baru membagikan screenshot beli 100 lot.
* **Hasil Deteksi Kit Sentimen di AI:**
  * *Rasio Noise:* 31% obrolan berasal dari akun dengan cashtag ganda yang mengajak beli tanpa analisa teknikal.
  * *Sinyal Divergence:* Mood obrolan 74% Bullish, namun frekuensi kata "guyur" dan "haki" melonjak 300% pada 30 menit terakhir penutupan sesi 2.
  * *Verdict AI:* **HIGH RISK EXIT LIQUIDITY**. Trader yang menggunakan Kit urung masuk, sementara ritel yang FOMO terkena guyuran ARB berhari-hari setelahnya.

### Kasus 2: $BUMI — Akumulasi Diam-diam di Balik Keluhan "Saham Ampas"
* **Konteks Pasar:** Harga saham bergerak mendatar di rentang sempit selama 2 minggu. Forum dipenuhi makian ritel: "Saham ampas", "Bandar pelit", "Kapok beli saham batubara".
* **Hasil Deteksi Kit Sentimen di AI:**
  * *Rasio Noise:* Rendah (<5%), akun buzzer kompor sudah menghilang karena saham dianggap tidak menarik.
  * *Sinyal Divergence:* Ritel 78% Pesimis/Frustrasi (fase *capitulation*), namun tidak ada aksi panic selling agresif.
  * *Verdict AI:* **ACCUMULATION BASE**. Fase kejenuhan ritel sering menjadi sinyal awal bandar mulai mengumpulkan barang murah sebelum ditarik naik kencang.

---

## 🧭 Panduan Membaca Hasil (Prinsip Anti-Nyangkut)

1. **Euforia Ekstrem (>80% Bullish) Sering Menandakan Pucuk:**  
   Ketika semua orang di forum merasa pasti kaya besok pagi, biasanya bandar sudah bersiap melepas barang (*exit liquidity*).
2. **Percepatan Obrolan (*Velocity*) Menandakan Minat:**  
   Lonjakan mention mendadak 3x lipat sering mendahului lonjakan volatilitas harga.
3. **Sentimen adalah Pelengkap, Bukan Sinyal Eksekusi Mandiri:**  
   Selalu padukan pembacaan sentimen ini dengan *Price Action* dan *Broker Summary / Flow Transaksi*.

---

## 💎 Akses Komunitas VIP & Pembaruan Kamus Seumur Hidup
Sebagai pemilik sah Kit Sentimen Ritel, kamu berhak mendapatkan pembaruan formula dan kamus berkala tanpa biaya tambahan:
* Kanal Telegram Resmi: **[t.me/lotmetrik](https://t.me/lotmetrik)**
* Konsultasi & Saran Istilah Slang Baru: Hubungi admin di grup komunitas.

---

🔒 **SECURITY & COPYRIGHT NOTICE**  
*ID Dokumen: LOTMETRIK-KSR-IDX-2026 • Lisensi Tunggal Pembeli Terdaftar.*  
*Diterbitkan resmi oleh Lotmetrik Research. Dibuat untuk riset mandiri trader saham Indonesia. Bukan ajakan jual-beli maupun rekomendasi investasi bursa.*
