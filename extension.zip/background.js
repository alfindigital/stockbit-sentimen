/* Stockbit Stream Scraper — service worker (MV3) v2.14.0
   Ringan & minimal: menangani klik icon extension di toolbar browser
   untuk langsung membuka / fokus ke tab Stockbit. */

'use strict';

chrome.action.onClicked.addListener(async () => {
  const patterns = ['https://stockbit.com/*', 'https://www.stockbit.com/*'];
  try {
    const tabs = await chrome.tabs.query({ url: patterns });
    if (tabs && tabs.length > 0) {
      await chrome.tabs.update(tabs[0].id, { active: true });
      if (tabs[0].windowId) {
        await chrome.windows.update(tabs[0].windowId, { focused: true });
      }
      return;
    }
  } catch (e) {
    // Abaikan error fallback
  }

  // Buka tab baru jika belum ada tab Stockbit aktif
  chrome.tabs.create({ url: 'https://stockbit.com/symbol/ANTM' });
});
