/* Stockbit Stream Scraper — content script (MV3) v2.14.0
   v2.14.0: Tombol 1-klik Buka AI, Smart Fallback bursa tutup/Senin pagi,
            Toggle Filter Noise langsung di UI, Indikator Sesi Bursa IDX di header.
   v2.13.0: hapus scheduler/timer background, fokus 100% real-time on-demand scraping,
            UI super ramping & performa sat-set.
   v2.12.0: add dynamic mood status badge, refine UI, strengthen graceful fallbacks. */

(function () {
  'use strict';
  if (window.__sspx) return; window.__sspx = true;
  const VER = '2.14.0';
  let hideNoise = false;

  const store = {
    get(k, d) { return new Promise(res => { try { chrome.storage.local.get([k], o => res(o && o[k] !== undefined ? o[k] : d)); } catch (e) { res(d); } }); },
    set(k, v) { return new Promise(res => { try { chrome.storage.local.set({ [k]: v }, res); } catch (e) { res(); } }); }
  };
  const $id = s => document.getElementById(s);

  /* ================= parsing core ================= */
  const RE = /^(\d{1,2})\s([A-Za-z]{3})\s(\d{2}),\s(\d{2}):(\d{2})(?!:)/;
  const MO = {
    Jan: 0, Feb: 1, Peb: 1, Mar: 2, Apr: 3, May: 4, Mei: 4, Jun: 5, Jul: 6, Aug: 7, Agu: 7, Agt: 7, Sep: 8, Oct: 9, Okt: 9, Nov: 10, Nop: 10, Dec: 11, Des: 11,
    jan: 0, feb: 1, peb: 1, mar: 2, apr: 3, may: 4, mei: 4, jun: 5, jul: 6, aug: 7, agu: 7, agt: 7, sep: 8, oct: 9, okt: 9, nov: 10, nop: 10, dec: 11, des: 11
  };
  const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const BADU = /^(Buy|Sell|Bid|Offer|Lot|RG|TS|TP|DYOR|RT|More|Read|Share|Reply|Follow|Following)$/i;
  const pad = n => String(n).padStart(2, '0');
  const fmt = d => `${d.getDate()} ${MON[d.getMonth()]} ${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const isoDay = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const localYMD = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; };

  function parseTime(s) {
    const m = String(s).match(RE); if (!m) return null;
    const mo = MO[m[2]] !== undefined ? MO[m[2]] : MO[m[2].toLowerCase()];
    if (mo === undefined) return null;
    const d = new Date(2000 + (+m[3]), mo, +m[1], +m[4], +m[5]);
    if (isNaN(d) || d.getFullYear() < 2015 || d.getTime() > Date.now() + 86400000) return null;
    return d;
  }
  const isUser = a => { const t = a.textContent.trim(); return !!t && /[A-Za-z]/.test(t) && /^[A-Za-z0-9_.]+$/.test(t) && !RE.test(t) && !/^Edited/i.test(t) && !BADU.test(t) && t.length <= 25; };
  const symbol = () => { const m = location.pathname.match(/\/symbol\/([A-Za-z0-9]+)/); return m ? m[1].toUpperCase() : 'STREAM'; };
  let streamRoot = null;
  function detectRoot() {
    const els = document.querySelectorAll('a,span,time');
    const f = [];
    for (let i=0; i<els.length && f.length<12; i++) {
      if (els[i].childElementCount === 0 && els[i].textContent.length < 30 && RE.test(els[i].textContent.trim())) f.push(els[i]);
    }
    if (f.length < 2) return document;
    let anc = []; let p = f[0]; while (p) { anc.push(p); p = p.parentElement; }
    for (let k = 1; k < f.length; k++) { const s = new Set(); let q = f[k]; while (q) { s.add(q); q = q.parentElement; } anc = anc.filter(a => s.has(a)); if (!anc.length) return document; }
    return anc[0] || document;
  }
  function postElOf(ts) {
    let p = ts, c = null;
    while (p.parentElement && p !== document.body) {
      p = p.parentElement;
      const hu = [...p.querySelectorAll('a')].some(isUser);
      if (hu) { const hp = [...p.querySelectorAll('p')].some(x => x.textContent.trim().length > 0); if (hp) return p; if (!c && [...p.querySelectorAll('a')].some(a => a.textContent.trim().startsWith('$'))) c = p; }
      if (p === streamRoot) break;
    }
    return c;
  }
  function userOf(pe, ts) { const cs = [...pe.querySelectorAll('a')].filter(isUser); let b = null; for (const a of cs) { if (a.compareDocumentPosition(ts) & 4) b = a; } return ((b || cs[0] || {}).textContent || '?').trim(); }
  function contentImgs(pe) { return [...pe.querySelectorAll('img')].filter(im => { const w = im.clientWidth || im.naturalWidth || 0; if (w < 120) return false; const a = im.closest('a'); const h = a && a.getAttribute('href') || ''; if (a && /^\/[A-Za-z0-9_.]+$/.test(h) && !/symbol/.test(h)) return false; return true; }).length; }
  function firstTicker(pe) { const a = [...pe.querySelectorAll('a')].map(x => x.textContent.trim()).find(t => /^\$[A-Z][A-Z0-9]{0,5}$/.test(t)); return a ? a.slice(1).toUpperCase() : ''; }
  function postType(user, txt, ci) {
    if (/^InsiderNews$/i.test(user)) return 'insider';
    if (/^StockbitNews$/i.test(user)) return 'news';
    if (/^StockbitReports$/i.test(user)) return 'laporan';
    const pm = txt.match(/MY (BULLISH|BEARISH) PREDICTION/i);
    if (pm) return pm[1].toLowerCase() === 'bullish' ? 'prediksi-bull' : 'prediksi-bear';
    if (/\b(Total votes|Ends in|Berakhir dalam|orang memilih|Lihat hasil polling)\b/i.test(txt)) return 'poll';
    if (ci > 0) return 'chart';
    return 'diskusi';
  }
  const CROSSABLE = new Set(['diskusi', 'chart', 'prediksi-bull', 'prediksi-bear']);

  function harvest(map, processed) {
    const sym = symbol();
    const els = (streamRoot || document).querySelectorAll('a,span,time');
    for (let i = 0; i < els.length; i++) {
      const ts = els[i];
      if (processed.has(ts)) continue;
      if (ts.childElementCount > 0) continue;
      const txt = ts.textContent;
      if (txt.length > 30) continue;
      const t = txt.trim();
      if (!RE.test(t)) { processed.add(ts); continue; } // Cache failures too!
      
      processed.add(ts);
      const d = parseTime(t); if (!d) continue;
      const pe = postElOf(ts); if (!pe) continue;
      const user = userOf(pe, ts);
      const rawTxt = pe.textContent;
      const ci = contentImgs(pe);
      let parts = [...pe.querySelectorAll('p')].map(x => x.innerText.replace(/\s+/g, ' ').trim()).filter(x => x && !(x.length <= 6 && /^[\d.,]+\s*(k|rb|jt|m)?$/i.test(x)));
      let text = parts.join(' ');
      const pm = rawTxt.match(/MY (?:BULLISH|BEARISH) PREDICTION[\s\S]*?(\d[\d.,]{0,6})\s*Target Price/i);
      const pred = pm ? pm[1].replace(/[.,]/g, '') : '';
      const cut = text.search(/MY (?:BULLISH|BEARISH) PREDICTION/i); if (cut >= 0) text = text.slice(0, cut).trim();
      if (!text) { const c = [...pe.querySelectorAll('a')].map(a => a.textContent.trim()).filter(tx => tx.startsWith('$')); text = c.length ? '[' + c.join(' ') + ']' : (ci ? '[gambar]' : '[kartu]'); }
      text = text.slice(0, 240);
      let type = postType(user, rawTxt, ci);
      const primary = firstTicker(pe);
      if (CROSSABLE.has(type) && primary && primary !== sym) type = 'crosstag';
      const key = user + '|' + d.getTime() + '|' + text.slice(0, 40);
      if (!map.has(key)) map.set(key, { d, user, text, pred, type });
    }
  }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let stopFlag = false, running = false, startedAt = 0;
  async function feedReady(maxMs) { const t0 = Date.now(); while (Date.now() - t0 < maxMs) { if (document.querySelectorAll('a,span,time').length > 50) return true; await sleep(500); } return true; }
  
  function feedBottomDate() {
    const els = (streamRoot || document).querySelectorAll('a,span,time');
    const ds = [];
    for (let i = els.length - 1; i >= 0 && ds.length < 8; i--) { 
      const el = els[i];
      if (el.childElementCount === 0) {
        const txt = el.textContent;
        if (txt.length < 30 && RE.test(txt.trim())) {
          const d = parseTime(txt.trim());
          if (d) ds.push(d.getTime());
        }
      }
    }
    if (!ds.length) return null;
    const mx = Math.max(...ds);
    const recent = ds.filter(t => mx - t < 30 * 86400000);
    return new Date(Math.min(...recent));
  }

  async function scrapeLoop(from, toEnd, onProgress) {
    if ((document.body.innerText || '').includes('Sesi Kamu Sudah Habis')) throw new Error('Sesi Stockbit kedaluwarsa. Silakan muat ulang halaman dan login kembali.');
    streamRoot = detectRoot(); const map = new Map(); const processed = new WeakSet(); let stale = 0;
    for (let i = 0; i < 400; i++) {
      if (stopFlag) break;
      harvest(map, processed); const bottom = feedBottomDate(); if (onProgress) onProgress(map.size, bottom);
      if (bottom && bottom < from) break;
      const before = map.size;
      
      window.scrollTo(0, document.body.scrollHeight);
      if (streamRoot && streamRoot !== document) { try { streamRoot.scrollTop = streamRoot.scrollHeight; } catch(e){} }
      
      let grew = false;
      for (let j = 0; j < 15; j++) {
        await sleep(140 + Math.floor(Math.random() * 60)); // jitter manusia 140-200ms (anti bot-detection)
        if (stopFlag) break;
        harvest(map, processed);
        if (map.size > before) { grew = true; break; }
      }
      if (!grew) { if (++stale >= 4) break; } else stale = 0;
    }
    harvest(map, processed);
    let posts = [...map.values()].filter(p => p.d >= from && (!toEnd || p.d < toEnd));
    posts.sort((a, b) => b.d - a.d); return posts;
  }
  function marketStatusBadge() {
    const now = new Date();
    const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
    const wib = new Date(utc + (7 * 3600000));
    const day = wib.getDay();
    const timeNum = wib.getHours() * 100 + wib.getMinutes();

    if (day === 0 || day === 6) {
      return { text: '🔴 Libur Weekend', bg: 'rgba(255,255,255,0.22)' };
    }
    if (day >= 1 && day <= 4) {
      if (timeNum < 900) return { text: '🟡 Pra-Bursa', bg: 'rgba(251,191,36,0.3)' };
      if (timeNum < 1200) return { text: '🟢 Sesi 1', bg: 'rgba(52,211,153,0.35)' };
      if (timeNum < 1330) return { text: '⏸️ Istirahat', bg: 'rgba(251,191,36,0.3)' };
      if (timeNum < 1550) return { text: '🟢 Sesi 2', bg: 'rgba(52,211,153,0.35)' };
      if (timeNum <= 1615) return { text: '🟠 Tutup Sesi', bg: 'rgba(249,115,22,0.35)' };
      return { text: '🔴 Bursa Tutup', bg: 'rgba(255,255,255,0.22)' };
    }
    if (day === 5) {
      if (timeNum < 900) return { text: '🟡 Pra-Bursa', bg: 'rgba(251,191,36,0.3)' };
      if (timeNum < 1130) return { text: '🟢 Sesi 1', bg: 'rgba(52,211,153,0.35)' };
      if (timeNum < 1400) return { text: '⏸️ Istirahat Jumat', bg: 'rgba(251,191,36,0.3)' };
      if (timeNum < 1550) return { text: '🟢 Sesi 2', bg: 'rgba(52,211,153,0.35)' };
      if (timeNum <= 1615) return { text: '🟠 Tutup Sesi', bg: 'rgba(249,115,22,0.35)' };
      return { text: '🔴 Bursa Tutup', bg: 'rgba(255,255,255,0.22)' };
    }
    return { text: '⚪ IDX', bg: 'rgba(255,255,255,0.2)' };
  }

  function computeCutoff(mode, dFrom, dTo) {
    if (mode === 'custom') {
      if (!dFrom) return null;
      const from = new Date(dFrom + 'T00:00:00'); if (isNaN(from)) return null;
      const tb = dTo ? new Date(dTo + 'T00:00:00') : from; if (isNaN(tb)) return null;
      if (tb < from) return { from: tb, toEnd: new Date(from.getTime() + 86400000) };
      return { from, toEnd: new Date(tb.getTime() + 86400000) };
    }
    const [y, m, d] = localYMD().split('-').map(Number);
    let N = { today: 0, d2: 1, d3: 2, d7: 6, d30: 29 }[mode] || 0;
    let smartNote = '';
    if (mode === 'today') {
      const now = new Date();
      const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
      const wib = new Date(utc + (7 * 3600000));
      const day = wib.getDay();
      const hour = wib.getHours();
      // Tier 2 No 6: Smart Fallback akhir pekan & Senin pagi pra-bursa
      if (day === 0) { N = 2; smartNote = 'Akhir pekan (Minggu): memuat data sejak Jumat.'; }
      else if (day === 6) { N = 1; smartNote = 'Akhir pekan (Sabtu): memuat data sejak Jumat.'; }
      else if (day === 1 && hour < 9) { N = 3; smartNote = 'Senin pra-bursa: memuat data sejak Jumat.'; }
    }
    return { from: new Date(y, m - 1, d - N, 0, 0, 0), toEnd: null, smartNote };
  }

  /* ================= auto-sentimen (kamus) — hanya post diskusi ================= */
  const RE_BULL = /\bara+\b|\bara+kan\b|araa|\bgas{2,}\b|gaspol|gaskeun|ngegas|roket|🚀|\bcabut\b|\botw\b|\bhaka\b|kejemput|terbang|melejit|\bhajar\b|\bcuan\b|\bking\b|breakout|tembus|ngacir|\bborong\b|\bakum\b|\bserok\b|\bmoon\b|\bijo\b|hijau|mantul|gacor|\brebound\b|\bdiangkat\b|\bcerah\b|\bbullish\b|\bmenarik\b|\bbagus\b|\bnaik\b|\bmeroket\b|\bsolid\b|\bpositif\b|\bkoleksi\b|\bkonsisten\b|panic buying|\bmoncer\b|\bcakep\b|\bugal\b|tarik ndar|\bbsjp\b|\bjajan\b|\buptrend\b|\bhold\b|\bcicil\b|lumayan|\btahan\b|\bdiskon\b|\bbob\b|\bbow\b|jemput\b|\bbagger\b|lompat kodok|curi start|duduk manis|dimakan semua|\bjebolin\b|\bhk\b|\bbo\b|\bkarungin\b|\bpungutin\b|\bberangkat\b|\blanjut\b|tambah muatan|tahan banting|lock ara|\bwenak\b|minta barang|cuan maksimal|big acc|sikat atas|\bup\b|dikerek|emiten kesayangan|berjilid|bersilit|akum terus|bandar masuk/i;
  const RE_BEAR = /loyo|berat|nyangkut|sangkut|syulit|\bsulit\b|\bcape\b|capek|\bdump\b|\bturun\b|merah|sisir|\bstuck\b|boncos|\bapes\b|ampas|sampah|jebak|hati-?hati|\bfear\b|koreksi|anjlok|ambruk|\barb\b|\brugi\b|pusing|gembel|payah|nyungsep|rontok|rungkad|\bkaratan\b|sekarat|wafat|kubur|merana|amsyong|\bzonk\b|sesak|nyesek|kandas|breakdown|distribusi|jebol|kurang bagus|kurang menarik|zona merah|putus asa|sengsara|\bbearish\b|\bruntuh\b|\bpecah\b|\bamburadul\b|\bphk\b|rompi oren|\bskip\b|banting harga|\bsadis\b|\bbahaya\b|\bhaki\b|ngehaki|\bcl\b|\bdowntrend\b|penggoreng|\blayu\b|\bsial\b|\bloss\b|\bambles\b|kurang bensin|\bminus\b|\bmales\b|\bpucuk\b|\bhoax\b|\bpanik\b|\bfake\b|\bdibanting\b|panic selling|kena sl|\bngeri\b|\btamat\b|\bnembokin\b|\bguyur\b|\bdiguyur\b|\blemas\b|\bbubar\b|\busai\b|\blongsor\b|\bpompom\b|balik kandang|\bdiganjel\b|\bngekos\b|\bmagerin\b|\bjunam\b|\bpager\b|\bmentok\b|\bterjun\b|\bwarning\b|take profit|dig dug|deg degan|dikocok|\bmual\b|nyapu sl|ngantri sell|jantungan|\bserem\b|digoyang|merah panjang|\bnangis\b|\bsuspend\b|bongkar ara|ara kebongkar|\btakut\b|\batut\b|mamam lu|\bangkatan\b|lelah sudah|psikis|kedoktrin|bid ompong|\balumni\b|sabuk pengaman|dijuramin|juram|ompong|nyangkuters/i;
  const PROMO_RE = /\bdm\b|screener|join\b|like and follow|mampir|ke profil|watchlist|sinyal tumpeh|kicau|maping|gratis gua|cutt\.ly|bit\.ly|t\.me|link\s*:|koh michael|jangan lupa|follow instagram|komunitas|community|tele\b|telegram|upgrade skill|saluran wa|wa kita|grup wa|rekom gratis|pc aja|dm aja/i;
  function classify(text) {
    const t = text.toLowerCase();
    if (PROMO_RE.test(t)) return 'promo';
    const b = RE_BULL.test(t), x = RE_BEAR.test(t);
    if (b && !x) return 'bull'; if (x && !b) return 'bear';
    if (b && x) { const nb = (t.match(new RegExp(RE_BULL, 'gi')) || []).length, nx = (t.match(new RegExp(RE_BEAR, 'gi')) || []).length; return nb >= nx ? 'bull' : 'bear'; }
    if ((text.match(/\$[A-Z]/g) || []).length >= 3) return 'promo';
    return 'net';
  }
  function sentimentStats(posts, onlyOrganic = false) {
    let disc = posts.filter(p => p.type === 'diskusi');
    if (onlyOrganic) {
      disc = disc.filter(p => classify(p.text) !== 'promo');
    }
    const c = { bull: 0, bear: 0, promo: 0, net: 0 };
    for (const p of disc) c[classify(p.text)]++;
    const n = disc.length || 1;
    return {
      n: disc.length,
      pct: {
        bull: Math.round(c.bull / n * 100),
        bear: Math.round(c.bear / n * 100),
        promo: onlyOrganic ? 0 : Math.round(c.promo / n * 100),
        net: Math.round(c.net / n * 100)
      },
      onlyOrganic
    };
  }
  function velocity(posts) {
    const byDay = {}; posts.forEach(p => { byDay[isoDay(p.d)] = (byDay[isoDay(p.d)] || 0) + 1; });
    const days = Object.keys(byDay).sort(); let delta = null;
    if (days.length >= 2) { const a = byDay[days[days.length - 2]], b = byDay[days[days.length - 1]]; delta = a ? Math.round((b - a) / a * 100) : null; }
    return { byDay, days, delta };
  }
  function renderVelocityChart(posts) {
    if (posts.length < 2) return '';
    const t0 = posts[posts.length-1].d.getTime();
    const t1 = posts[0].d.getTime();
    const hours = (t1 - t0) / 3600000;
    
    let binMs = 3600000; let lbl = 'per jam';
    if (hours > 72) { binMs = 86400000; lbl = 'per hari'; }
    else if (hours > 24) { binMs = 14400000; lbl = 'per 4 jam'; }
    
    const binStart = d => {
        if (binMs === 86400000) return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
        if (binMs === 14400000) return new Date(d.getFullYear(), d.getMonth(), d.getDate(), Math.floor(d.getHours()/4)*4).getTime();
        return new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours()).getTime();
    };
    
    const bins = {}; let maxC = 0;
    posts.forEach(p => { const k = binStart(p.d); bins[k] = (bins[k] || 0) + 1; if (bins[k] > maxC) maxC = bins[k]; });
    const keys = Object.keys(bins).map(Number).sort((a,b)=>a-b);
    if (keys.length < 2) return '';
    
    const fullKeys = [];
    for(let k = keys[0]; k <= keys[keys.length-1]; k += binMs) fullKeys.push(k);
    
    const bars = fullKeys.map(k => {
        const c = bins[k] || 0;
        const h = maxC > 0 ? Math.max(2, Math.round((c/maxC)*100)) : 0;
        const d = new Date(k);
        const title = binMs === 86400000 ? isoDay(d) : `${pad(d.getHours())}:00`;
        return `<div style="flex:1;background:var(--spx-bg-alt);border-radius:2px;display:flex;align-items:flex-end;position:relative" class="spx-bar" data-tip="${title} -> ${c} post"><div style="width:100%;background:${c===0?'var(--spx-border)':'var(--spx-primary)'};border-radius:2px;height:${c===0?2:h}%"></div></div>`;
    }).join('');
    
    return `<div style="margin-top:12px;border-top:1px dashed #E2E8F0;padding-top:10px"><div style="font-size:10.5px;color:#8A99AD;text-transform:uppercase;font-weight:800;margin-bottom:6px;letter-spacing:0.5px">Kepadatan Trafik (${lbl})</div><div style="height:36px;display:flex;gap:2px">${bars}</div></div>`;
  }
  function readPriceData() {
    const text = (document.body.innerText || '').slice(0, 2500);
    const m = text.match(/([\d,]+)\s*(?:▼|▲|[-+])?\s*([+-]?[\d,]+)\s*\(([+-]?\d+(?:[.,]\d+)?)%\)/);
    if (m) return { price: m[1], change: parseFloat(m[3].replace(',', '.')) };
    return null;
  }
  function formatTargets(preds, type) {
    const arr = preds.filter(p => p.type === type && p.pred && parseInt(p.pred, 10) > 0).map(p => parseInt(p.pred, 10));
    if (!arr.length) return '-';
    if (arr.length === 1) return arr[0];
    arr.sort((a,b)=>a-b);
    const min = arr[0], max = arr[arr.length - 1];
    if (min === max || max - min <= max * 0.1) return `${min}`;
    return `${min} - ${max}`;
  }
  function typeCounts(posts) { const c = {}; for (const p of posts) c[p.type] = (c[p.type] || 0) + 1; return c; }
  function topStats(posts) {
    const byUser = {}, tk = {}, sym = symbol();
    for (const p of posts) { byUser[p.user] = (byUser[p.user] || 0) + 1; for (const t of (p.text.match(/\$[A-Z][A-Z0-9]{1,5}/g) || [])) if (t !== '$' + sym) tk[t] = (tk[t] || 0) + 1; }
    return { users: Object.keys(byUser).length, top: Object.entries(byUser).sort((a, b) => b[1] - a[1]).slice(0, 8), topTk: Object.entries(tk).sort((a, b) => b[1] - a[1]).slice(0, 8) };
  }
  const TYPE_LABEL = { diskusi: 'Diskusi', chart: 'Chart', news: 'News', insider: 'Insider', laporan: 'Laporan', poll: 'Poll', 'prediksi-bull': 'Prediksi🟢', 'prediksi-bear': 'Prediksi🔴' };
  function csvEsc(s) { let v = String(s); if (/^[=+\-@\t\r]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; }
  function toCSV(posts) { return 'tanggal,jam,user,tipe,sentimen,target,teks\n' + posts.map(p => [isoDay(p.d), pad(p.d.getHours()) + ':' + pad(p.d.getMinutes()), p.user, p.type, p.type === 'diskusi' ? classify(p.text) : '', p.pred, p.text].map(csvEsc).join(',')).join('\n'); }
  function cleanText(posts, sym) {
    if (!posts.length) return '';
    const a = posts[posts.length - 1].d, b = posts[0].d;
    return `# Stream $${sym} — ${posts.length} post — ${fmt(a)} - ${fmt(b)}\n# format: [tgl jam] user (tipe/sentimen): teks · cross-tag = post yg cuma numpang tag (abaikan)\n\n` +
      posts.map(p => { const tag = p.type === 'diskusi' ? classify(p.text) : p.type; return `[${fmt(p.d)}] ${p.user} (${tag}): ${p.text}${p.pred ? ` [TP ${p.pred}]` : ''}`; }).join('\n');
  }
  function fullReport(posts, sym) {
    const s = sentimentStats(posts), v = velocity(posts), st = topStats(posts), tc = typeCounts(posts);
    const preds = posts.filter(p => p.pred);
    const L = [];
    L.push(`LAPORAN SENTIMEN RITEL — $${sym}`);
    L.push(`Periode: ${fmt(posts[posts.length - 1].d)} - ${fmt(posts[0].d)} • ${posts.length} post • ${st.users} user`);
    L.push('');
    L.push(`SENTIMEN (${s.n} post, kamus kata): Bullish ${s.pct.bull}% | Bearish ${s.pct.bear}% | Netral ${s.pct.net + s.pct.promo}%`);
    if (v.delta != null) L.push(`VELOCITY: post hari terakhir ${v.delta >= 0 ? '+' : ''}${v.delta}% vs sebelumnya`);
    const validTc = Object.entries(tc).filter(([k]) => !['crosstag', 'news', 'insider', 'laporan'].includes(k));
    L.push('TIPE POST: ' + validTc.sort((a, b) => b[1] - a[1]).map(([k, n]) => (TYPE_LABEL[k] || k) + ' ' + n).join(' • '));
    if (preds.length) { L.push(`PREDIKSI: ${preds.filter(p => p.type === 'prediksi-bull').length} bull / ${preds.filter(p => p.type === 'prediksi-bear').length} bear`); L.push(`TARGET BULLISH: ${formatTargets(preds, 'prediksi-bull')}`); L.push(`TARGET BEARISH: ${formatTargets(preds, 'prediksi-bear')}`); }
    L.push(`Top poster: ${st.top.slice(0, 5).map(t => t[0] + '(' + t[1] + ')').join(', ')}`);
    L.push('');
    L.push('*Sentimen hanya dari post diskusi (berita & cross-tag diabaikan). Alat bantu riset, bukan rekomendasi jual-beli.*');
    return L.join('\n');
  }

  /* ================= UI (design-system lotmetrik) ================= */
  const CSS = `
  #spx-panel { --spx-bg: rgba(255,255,255,0.98); --spx-text: #0B1F3A; --spx-border: #D7DEE7; --spx-card: #fff; --spx-card-border: #EAEEF3; --spx-text-muted: #8A99AD; --spx-text-sec: #5F7186; --spx-bg-sec: #F9FAFB; --spx-bg-alt: #F1F5F9; --spx-primary: #10B981; --spx-head-bg1: #10B981; --spx-head-bg2: #059669; --spx-head-text: #fff; --spx-shadow: rgba(5,150,105,0.15); --spx-btn-sec-bg: #D1FAE5; --spx-btn-sec-text: #047857; --spx-btn-sec-hover: #A7F3D0; --spx-btn-alt-bg: #F1F5F9; --spx-btn-alt-text: #475569; --spx-btn-alt-hover: #E2E8F0; --spx-dot: #fff; --spx-toggle-bg: #CBD5E1; }
  #spx-panel.spx-dark { --spx-bg: rgba(20,25,32,0.98); --spx-text: #F8FAFC; --spx-border: #334155; --spx-card: #1E293B; --spx-card-border: #334155; --spx-text-muted: #94A3B8; --spx-text-sec: #CBD5E1; --spx-bg-sec: #0F172A; --spx-bg-alt: #334155; --spx-primary: #10B981; --spx-head-bg1: #0F172A; --spx-head-bg2: #1E293B; --spx-head-text: #10B981; --spx-shadow: rgba(0,0,0,0.4); --spx-btn-sec-bg: #065F46; --spx-btn-sec-text: #D1FAE5; --spx-btn-sec-hover: #047857; --spx-btn-alt-bg: #334155; --spx-btn-alt-text: #F1F5F9; --spx-btn-alt-hover: #475569; --spx-dot: #10B981; --spx-toggle-bg: #475569; }
  #spx-panel{position:fixed;right:16px;top:16px;height:calc(100vh - 32px);max-height:calc(100vh - 32px);width:380px;color:var(--spx-text);background:var(--spx-bg);border:1px solid var(--spx-border);border-radius:12px;box-shadow:0 8px 30px var(--spx-shadow);display:flex;flex-direction:column;transition:transform 0.3s ease;z-index:2147483000;font:14.5px/1.5 'Plus Jakarta Sans',system-ui,sans-serif;overflow:hidden}
  #spx-fab{position:fixed;z-index:2147483000;font:14.5px/1.5 'Plus Jakarta Sans',system-ui,sans-serif;right:16px;bottom:16px;width:52px;height:52px;border-radius:50%;background:var(--spx-head-bg1);color:var(--spx-primary);border:1px solid var(--spx-border);font-size:22px;cursor:pointer;box-shadow:0 6px 20px rgba(5,150,105,.25);display:none;transition:transform 0.2s}#spx-fab:hover{transform:scale(1.05)}
  #spx-panel *{box-sizing:border-box}#spx-panel .mono{font-family:'JetBrains Mono',ui-monospace,monospace}
  #spx-head{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;background:linear-gradient(135deg, var(--spx-head-bg1), var(--spx-head-bg2));color:var(--spx-head-text);font-weight:700;cursor:grab;user-select:none;font-size:15px;flex-shrink:0}#spx-head .dot{color:var(--spx-dot);margin-right:6px}#spx-head button{background:transparent;border:0;color:currentColor;opacity:0.7;cursor:pointer;font-size:18px;padding:0;transition:opacity 0.2s;margin-left:8px}#spx-head button:hover{opacity:1}
  #spx-tabs{display:flex;border-bottom:1px solid var(--spx-card-border);background:var(--spx-card);flex-shrink:0}#spx-tabs button{flex:1;padding:12px;border:0;background:transparent;color:var(--spx-text-muted);font-weight:700;cursor:pointer;border-bottom:2px solid transparent;font-size:14.5px;transition:all 0.2s}#spx-tabs button:hover{color:var(--spx-text)}#spx-tabs button.on{color:var(--spx-text);border-bottom-color:var(--spx-primary)}
  #spx-body{padding:18px;overflow-y:auto;overflow-x:hidden;flex:1 1 0;min-height:0;overscroll-behavior:contain}#spx-body label{display:block;font-size:13px;color:var(--spx-text-sec);margin:12px 0 6px;font-weight:600}
  #spx-body::-webkit-scrollbar{width:6px}#spx-body::-webkit-scrollbar-track{background:transparent}#spx-body::-webkit-scrollbar-thumb{background:var(--spx-border);border-radius:3px}#spx-body::-webkit-scrollbar-thumb:hover{background:var(--spx-text-muted)}
  #spx-body select,#spx-body input[type="text"],#spx-body input[type="time"]{width:100%;padding:10px 14px;border:1px solid var(--spx-border);border-radius:8px;font:14.5px 'Plus Jakarta Sans',system-ui;color:var(--spx-text);background:var(--spx-bg-sec);transition:border-color 0.2s;outline:none}#spx-body select:focus,#spx-body input:focus{border-color:var(--spx-primary);background:var(--spx-card)}
  .spx-2{display:flex;gap:12px}.spx-2>*{flex:1}
  .spx-btn{width:100%;padding:12px;margin-top:14px;border:0;border-radius:8px;background:var(--spx-primary);color:#fff;font-weight:700;cursor:pointer;font-size:15px;transition:all 0.2s;box-shadow:0 2px 8px rgba(20,184,166,.25)}.spx-btn:hover{background:#0D7A70;transform:translateY(-1px);box-shadow:0 4px 12px rgba(20,184,166,.3)}
  .spx-btn.sec{background:var(--spx-btn-sec-bg);color:var(--spx-btn-sec-text);box-shadow:none}.spx-btn.sec:hover{background:var(--spx-btn-sec-hover);transform:translateY(-1px)}
  .spx-btn.sec-alt{background:var(--spx-btn-alt-bg);color:var(--spx-btn-alt-text);box-shadow:none;cursor:pointer;border:0;border-radius:8px;font-weight:700;font-size:14.5px}.spx-btn.sec-alt:hover{background:var(--spx-btn-alt-hover);transform:translateY(-1px);color:var(--spx-text)}
  .spx-btn.stop{background:#EF4444;box-shadow:0 2px 8px rgba(239,68,68,.25)}.spx-btn.stop:hover{background:#DC2626;box-shadow:0 4px 12px rgba(239,68,68,.3)}.spx-btn:disabled{opacity:.6;cursor:not-allowed;transform:none}
  #spx-prog{font-size:13.5px;color:var(--spx-text-sec);margin-top:12px;min-height:18px;font-weight:500}
  #spx-out{margin-top:4px;display:none;animation:spxFadeIn 0.3s ease}@keyframes spxFadeIn{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
  .spx-card{background:var(--spx-card);border:1px solid var(--spx-card-border);border-radius:10px;padding:14px;margin-top:10px;box-shadow:0 2px 6px rgba(0,0,0,.02)}.spx-card h4{margin:0 0 10px;font-size:12px;letter-spacing:.05em;text-transform:uppercase;color:var(--spx-text-muted);font-weight:800}
  .spx-senti{display:flex;height:8px;border-radius:4px;overflow:hidden;margin:6px 0 10px;background:var(--spx-border)}.spx-senti i{display:block;height:100%}
  .spx-kv{font-size:14px;color:var(--spx-text);margin:4px 0;line-height:1.5}.spx-kv b{font-weight:700}.spx-big{font-size:24px;font-weight:800;letter-spacing:-0.02em}
  .spx-chip{display:inline-block;background:var(--spx-bg-alt);color:var(--spx-text);border-radius:6px;padding:3px 10px;margin:4px 6px 0 0;font-size:12.5px;font-weight:600;border:1px solid var(--spx-border)}
  .spx-bar:hover::after { content: attr(data-tip); position: absolute; bottom: 100%; left: 50%; transform: translateX(-50%); background: var(--spx-text); color: var(--spx-bg); padding: 4px 8px; border-radius: 4px; font-size: 11px; white-space: nowrap; z-index: 10; pointer-events: none; margin-bottom: 4px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
  #spx-help p{margin:6px 0;font-size:14.5px;color:var(--spx-text);line-height:1.5}
  #spx-help ul{margin:6px 0;padding-left:24px;color:var(--spx-text)}#spx-help li{margin:4px 0;font-size:14.5px}
  #spx-help .q{font-weight:800;color:var(--spx-text);margin:20px 0 6px;font-size:15.5px;display:flex;align-items:center;gap:8px}
  #spx-help .q:first-child{margin-top:4px}
  #spx-help .q::before{content:'';display:block;width:4px;height:16px;background:var(--spx-primary);border-radius:2px}
  #spx-help a{color:var(--spx-primary);font-weight:700;text-decoration:none}#spx-help a:hover{text-decoration:underline}
  .spx-note{font-size:12px;color:var(--spx-text-muted);margin-top:8px;line-height:1.4}
  .spx-disclaimer{font-size:11.5px;color:var(--spx-text-muted);font-style:italic;text-align:center;margin-top:20px;padding-top:12px;border-top:1px dashed var(--spx-border)}
  @keyframes spxPulse { 0% { box-shadow: 0 0 0 0 rgba(16,185,129,0.5); } 70% { box-shadow: 0 0 0 8px rgba(16,185,129,0); } 100% { box-shadow: 0 0 0 0 rgba(16,185,129,0); } }
  #spx-run { animation: spxPulse 2s 1; }
  .spx-cal-popup { position:absolute; top:45px; left:0; width:100%; background:var(--spx-card); border:1px solid var(--spx-border); border-radius:10px; box-shadow:0 8px 30px var(--spx-shadow); z-index:100; display:none; padding:12px; font-size:13.5px; color:var(--spx-text) }
  .spx-cal-header { display:flex; justify-content:space-between; align-items:center; font-weight:bold; margin-bottom:10px }
  .spx-cal-header button { border:0; background:transparent; cursor:pointer; font-size:16px; color:var(--spx-text-muted); padding:4px 8px }
  .spx-cal-header button:hover { color:var(--spx-text) }
  .spx-cal-grid { display:grid; grid-template-columns:repeat(7, 1fr); gap:4px; text-align:center }
  .spx-cal-grid .dh { font-weight:bold; color:var(--spx-text-muted); font-size:12px; padding:4px 0 }
  .spx-cal-day { padding:6px 0; cursor:pointer; border-radius:4px; transition:background 0.2s }
  .spx-cal-day:hover { background:var(--spx-bg-alt) }
  .spx-cal-day.muted { color:var(--spx-text-muted); opacity:0.5 }
  .spx-cal-day.sel { background:var(--spx-primary); color:#fff; font-weight:bold }
  .spx-cal-day.in-range { background:var(--spx-btn-sec-bg); color:var(--spx-text) }
  `;
  const el = h => { const t = document.createElement('template'); t.innerHTML = h.trim(); return t.content.firstChild; };
  let lastResult = null, lastErr = '';

  async function mount() {
    if ($id('spx-panel') || $id('sp-panel')) return;
    const style = document.createElement('style'); style.textContent = CSS; document.documentElement.appendChild(style);
    const I_SUN = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>`;
    const I_MOON = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>`;
    const I_MIN = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line></svg>`;
    const I_FAB = `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>`;
    const fab = el(`<button id="spx-fab" title="Stream Scraper" style="display:flex;align-items:center;justify-content:center">${I_FAB}</button>`);
    const panel = el(`<div id="spx-panel">
      <div id="spx-head" style="background:var(--spx-primary);color:#fff;padding:12px 16px;display:flex;justify-content:space-between;align-items:center;border-radius:12px 12px 0 0;font-size:15px;position:sticky;top:0;z-index:10">
        <div style="font-weight:700;display:flex;align-items:center;gap:8px">
          <div style="display:flex;flex-direction:column">
            <div style="display:flex;align-items:center;gap:6px">
              <span><span class="dot" style="font-size:10px;vertical-align:middle;margin-right:4px">◆</span>Stockbit Stream Scraper</span>
              <span id="spx-market-status" style="font-size:10px;padding:2px 7px;border-radius:10px;background:rgba(255,255,255,0.22);font-weight:700;letter-spacing:0.2px">IDX</span>
            </div>
            <div style="font-size:10px;opacity:0.8;margin-left:14px;font-weight:normal;line-height:1">v${VER}</div>
          </div>
        </div>
        <div style="display:flex;gap:12px;align-items:center">
          <button id="spx-theme" title="Ubah Tema" style="background:transparent;border:0;color:currentColor;cursor:pointer">${I_MOON}</button>
          <button id="spx-min" title="Kecilkan" style="background:transparent;border:0;color:currentColor;cursor:pointer">${I_MIN}</button>
        </div>
      </div>
      <div id="spx-tabs"><button id="spx-tb-a" class="on">Analisa</button><button id="spx-tb-h">Panduan</button></div>
      <div id="spx-body">
        <div id="spx-tab-a">
          <div style="margin-bottom:12px;display:flex;align-items:center;justify-content:space-between">
            <span style="font-weight:600">Emiten: <span id="spx-sym" class="mono">$${symbol()}</span></span>
          </div>
          <label>Ambil dari/sampai tanggal:</label>
          <div style="position:relative">
            <div id="spx-cal-toggle" style="display:flex;align-items:center;justify-content:center;margin:8px 0;background:var(--spx-bg-sec);padding:10px 14px;border:1px solid var(--spx-border);border-radius:8px;cursor:pointer">
              <span id="spx-d-label" style="font-weight:700;font-size:14.5px;">Hari ini</span>
            </div>
            <div id="spx-cal-popup" class="spx-cal-popup">
              <div class="spx-cal-header">
                <button id="spx-cal-prev">&lt;</button>
                <span id="spx-cal-title"></span>
                <button id="spx-cal-next">&gt;</button>
              </div>
              <div class="spx-cal-grid" id="spx-cal-grid"></div>
            </div>
          </div>
          <input type="hidden" id="spx-from" />
          <div id="spx-presets" class="spx-2" style="margin-bottom:14px;gap:8px">
            <button class="spx-btn sec-alt spx-preset" data-val="today" style="margin-top:0;padding:6px;font-size:11.5px;font-weight:600">Hari ini</button>
            <button class="spx-btn sec-alt spx-preset" data-val="d3" style="margin-top:0;padding:6px;font-size:11.5px;font-weight:600">3 Hari</button>
            <button class="spx-btn sec-alt spx-preset" data-val="d7" style="margin-top:0;padding:6px;font-size:11.5px;font-weight:600">7 Hari</button>
            <button class="spx-btn sec-alt spx-preset" data-val="d30" style="margin-top:0;padding:6px;font-size:11.5px;font-weight:600">30 Hari</button>
          </div>
          <input type="hidden" id="spx-to" />
          <input type="hidden" id="spx-mode" value="today" />
          <button class="spx-btn" id="spx-run">Mulai Scrape 🚀</button>
          <div id="spx-prog"></div>
          <div id="spx-out"></div>
          <div class="spx-2" id="spx-actions" style="display:none;gap:6px">
            <button class="spx-btn sec" id="spx-txt" title="Salin format laporan AI" style="padding:10px 4px;font-size:12.5px"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px;margin-right:2px"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>Salin</button>
            <button class="spx-btn sec" id="spx-ai" title="Salin data dan buka tab ChatGPT" style="padding:10px 4px;font-size:12.5px;background:var(--spx-btn-sec-hover)"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px;margin-right:2px"><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/></svg>Buka AI 🚀</button>
            <button class="spx-btn sec" id="spx-csv" title="Unduh data format CSV" style="padding:10px 4px;font-size:12.5px">⬇ CSV</button>
          </div>
          <div id="spx-hist" style="margin-top:8px"></div>
        </div>
        <div id="spx-help" style="display:none"></div>
      </div>
    </div>`);
    document.documentElement.appendChild(fab); document.documentElement.appendChild(panel);
    const $ = s => panel.querySelector(s);

    $('#spx-help').innerHTML = HELP_HTML();
    
    const hist = await store.get(`hist_${symbol()}`, null);
    
    const head = $('#spx-head');
    let isDrag = false, dx=0, dy=0;
    head.addEventListener('mousedown', e => {
      if(e.target.tagName==='BUTTON' || e.target.closest('button')) return;
      isDrag = true;
      const rect = panel.getBoundingClientRect();
      dx = e.clientX - rect.left; dy = e.clientY - rect.top;
      panel.style.transition = 'none';
    });
    document.addEventListener('mousemove', e => {
      if(!isDrag) return;
      let left = e.clientX - dx, top = e.clientY - dy;
      panel.style.right = 'auto';
      panel.style.left = left + 'px';
      panel.style.top = top + 'px';
    });
    document.addEventListener('mouseup', () => {
      if(isDrag) { isDrag = false; panel.style.transition = 'transform 0.3s ease'; }
    });

    const initialPd = readPriceData();
    const themeBtn = $('#spx-theme');
    const toggleTheme = () => {
      const isDark = panel.classList.toggle('spx-dark');
      themeBtn.innerHTML = isDark ? I_SUN : I_MOON;
      store.set('theme', isDark ? 'dark' : 'light');
    };
    themeBtn.addEventListener('click', toggleTheme);
    store.get('theme', 'light').then(th => {
      if (th === 'dark') { panel.classList.add('spx-dark'); themeBtn.innerHTML = I_SUN; }
    });

    const tabA = $('#spx-tb-a'), tabH = $('#spx-tb-h');
    const switchTab = (t) => {
      tabA.classList.toggle('on', t === 'a');
      tabH.classList.toggle('on', t === 'h');
      $('#spx-tab-a').style.display = t === 'a' ? '' : 'none';
      $('#spx-help').style.display = t === 'h' ? 'block' : 'none';
    };
    tabA.addEventListener('click', () => switchTab('a'));
    tabH.addEventListener('click', () => switchTab('h'));

    const $m = $('#spx-mode'), $l = $('#spx-d-label'), $f = $('#spx-from'), $t = $('#spx-to');
    const offsetDate = (days) => { const [y, m, d] = localYMD().split('-').map(Number); const dt = new Date(y, m - 1, d + days, 0, 0, 0); return dt.getFullYear() + '-' + String(dt.getMonth() + 1).padStart(2, '0') + '-' + String(dt.getDate()).padStart(2, '0'); };
    const niceD = (ymd) => { if (!ymd) return ''; const [y, m, d] = ymd.split('-'); return parseInt(d) + ' ' + ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agt','Sep','Okt','Nov','Des'][parseInt(m)-1] + (y !== new Date().getFullYear().toString() ? ' '+y : ''); };
    const padDT = n => String(n).padStart(2, '0');
    const ymdFmt = d => `${d.getFullYear()}-${padDT(d.getMonth() + 1)}-${padDT(d.getDate())}`;

    const updateDateUI = () => { 
      if ($m.value === 'custom') { 
        if ($f.value && $t.value && new Date($f.value) > new Date($t.value)) { const tmp = $f.value; $f.value = $t.value; $t.value = tmp; }
        $l.textContent = niceD($f.value) + ($t.value && $t.value !== $f.value ? ' s/d ' + niceD($t.value) : ''); 
      } else { 
        $l.textContent = $m.value === 'today' ? 'Hari ini' : ($m.value === 'd3' ? '3 Hari Terakhir' : ($m.value === 'd7' ? '7 Hari Terakhir' : '30 Hari Terakhir')); 
      } 
    };

    let calStart = null, calEnd = null, calMonth = new Date(), calClicks = 0;
    const renderCal = () => {
      const g = $('#spx-cal-grid'); g.innerHTML = '';
      const t = $('#spx-cal-title');
      const mo = calMonth.getMonth(), yr = calMonth.getFullYear();
      t.textContent = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agt','Sep','Okt','Nov','Des'][mo] + ' ' + yr;
      ['M','S','S','R','K','J','S'].forEach(d => { const s = document.createElement('div'); s.className='dh'; s.textContent=d; g.appendChild(s); });
      const fd = new Date(yr, mo, 1).getDay(), dInM = new Date(yr, mo+1, 0).getDate();
      const prevD = new Date(yr, mo, 0).getDate();
      for(let i=fd-1; i>=0; i--) { const d=document.createElement('div'); d.className='spx-cal-day muted'; d.textContent=prevD-i; g.appendChild(d); }
      for(let i=1; i<=dInM; i++) {
        const d = document.createElement('div'); d.className='spx-cal-day'; d.textContent=i;
        const curD = new Date(yr, mo, i, 0, 0, 0).getTime();
        const str = `${yr}-${String(mo+1).padStart(2,'0')}-${String(i).padStart(2,'0')}`;
        
        let isS = false, isE = false, inR = false;
        if (calStart && curD === calStart.getTime()) isS = true;
        if (calEnd && curD === calEnd.getTime()) isE = true;
        if (calStart && calEnd && curD > calStart.getTime() && curD < calEnd.getTime()) inR = true;
        
        if(isS || isE) d.classList.add('sel');
        else if(inR) d.classList.add('in-range');
        
        d.addEventListener('click', (e) => {
          e.stopPropagation();
          if (calClicks === 0 || calClicks === 2) { calStart = new Date(yr, mo, i, 0,0,0); calEnd = null; calClicks = 1; }
          else { 
            calEnd = new Date(yr, mo, i, 0,0,0); 
            if (calEnd < calStart) { const tmp=calStart; calStart=calEnd; calEnd=tmp; }
            calClicks = 2; 
            $f.value = ymdFmt(calStart); $t.value = ymdFmt(calEnd); $m.value = 'custom'; updateDateUI();
            $('#spx-cal-popup').style.display='none';
          }
          renderCal();
        });
        g.appendChild(d);
      }
    };
    
    $('#spx-cal-toggle').addEventListener('click', () => {
      const p = $('#spx-cal-popup');
      if (p.style.display === 'block') { p.style.display = 'none'; }
      else { p.style.display = 'block'; renderCal(); }
    });
    $('#spx-cal-prev').addEventListener('click', (e) => { e.stopPropagation(); calMonth.setMonth(calMonth.getMonth()-1); renderCal(); });
    $('#spx-cal-next').addEventListener('click', (e) => { e.stopPropagation(); calMonth.setMonth(calMonth.getMonth()+1); renderCal(); });
    document.addEventListener('click', e => {
      if (!$('#spx-cal-toggle').contains(e.target) && !$('#spx-cal-popup').contains(e.target)) {
        $('#spx-cal-popup').style.display = 'none';
      }
    });

    panel.querySelectorAll('.spx-preset').forEach(b => b.addEventListener('click', e => { 
      const v = e.target.getAttribute('data-val'); $m.value = v; 
      if (v === 'd3') { $f.value = offsetDate(-2); $t.value = offsetDate(0); } 
      else if (v === 'd7') { $f.value = offsetDate(-6); $t.value = offsetDate(0); } 
      else if (v === 'd30') { $f.value = offsetDate(-29); $t.value = offsetDate(0); } 
      else { $f.value = offsetDate(0); $t.value = offsetDate(0); } 
      updateDateUI(); 
      calClicks = 0; calStart = null; calEnd = null;
    }));
    updateDateUI();
    $('#spx-min').addEventListener('click', () => { panel.style.display = 'none'; fab.style.display = 'block'; });
    fab.addEventListener('click', () => { panel.style.display = 'block'; fab.style.display = 'none'; $('#spx-sym').textContent = '$' + symbol(); });
    $('#spx-run').addEventListener('click', () => { if (running) { if (Date.now() - startedAt > 600) stopFlag = true; } else runScrape(false); });
    window.addEventListener('wheel', () => { if (running) stopFlag = true; }, { passive: true });
    window.addEventListener('touchstart', () => { if (running) stopFlag = true; }, { passive: true });
    $('#spx-txt').addEventListener('click', () => lastResult && copy(fullReport(lastResult.posts, lastResult.sym) + '\n\n===== POST (mentah) =====\n\n' + cleanText(lastResult.posts, lastResult.sym), '#spx-txt'));
    $('#spx-ai').addEventListener('click', async () => {
      if (!lastResult) return;
      const t = cleanText(lastResult.posts, lastResult.sym);
      await copy(t, '#spx-ai');
      window.open('https://chatgpt.com/', '_blank');
    });
    $('#spx-csv').addEventListener('click', () => {
      if (!lastResult) return;
      dl(toCSV(lastResult.posts), `stream-${lastResult.sym}-${isoDay(new Date())}.csv`, 'text/csv');
    });
    $('#spx-help').addEventListener('click', e => { const id = e.target && e.target.id; if (id === 'spx-help-diag') copy(diagText(), '#spx-help-diag'); });

    const updateMarketBadge = () => {
      const elB = $('#spx-market-status');
      if (!elB) return;
      const st = marketStatusBadge();
      elB.textContent = st.text;
      elB.style.background = st.bg;
    };
    updateMarketBadge();
    setInterval(updateMarketBadge, 15000);
  }

  async function copy(t, sel) {
    let ok = false;
    try { await navigator.clipboard.writeText(t); ok = true; }
    catch (e) { try { const ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); ok = document.execCommand('copy'); ta.remove(); } catch (e2) {} }
    const b = document.querySelector(sel); if (b) {
      const o = b.innerHTML, obg = b.style.background, oc = b.style.color;
      b.textContent = ok ? 'Tersalin ✓' : 'Gagal';
      if (ok) { b.style.background = '#10B981'; b.style.color = '#fff'; }
      setTimeout(() => { b.innerHTML = o; b.style.background = obg; b.style.color = oc; }, 1300);
    }
  }
  function dl(text, fn, mime) { const url = URL.createObjectURL(new Blob([text], { type: (mime || 'text/plain') + ';charset=utf-8' })); const a = document.createElement('a'); a.href = url; a.download = fn; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000); }
  function diagText() { const bad = (document.body.innerText || '').includes('Sesi Kamu Sudah Habis'); return ['=== Diagnostik Stockbit Stream Scraper ===', 'Versi: ' + VER, 'Emiten: $' + symbol(), 'URL: ' + location.href, 'Post feed termuat: ' + tsLeavesIn(document).length, 'Hasil terakhir: ' + (lastResult ? lastResult.posts.length + ' post' : '-'), 'Login aktif: ' + (bad ? 'TIDAK (login ulang)' : 'kelihatannya ya'), 'Error: ' + (lastErr || '-'), 'Browser: ' + navigator.userAgent, 'Waktu: ' + new Date().toString()].join('\n'); }

  async function runScrape(isAuto, forceMode, forceFrom, forceTo) {
    if (running) return null;
    running = true; stopFlag = false; startedAt = Date.now(); lastErr = '';
    const prog = $id('spx-prog'), runBtn = $id('spx-run');
    const mode = forceMode || ($id('spx-mode') ? $id('spx-mode').value : 'today');
    const dFrom = (forceFrom !== undefined) ? forceFrom : ($id('spx-from') ? $id('spx-from').value : '');
    const dTo = (forceTo !== undefined) ? forceTo : ($id('spx-to') ? $id('spx-to').value : '');
    const sym = symbol();
    if (runBtn) { runBtn.textContent = '■ Stop'; runBtn.classList.add('stop'); }
    const out = $id('spx-out'); if (out) out.style.display = 'none';
    const act = $id('spx-actions'); if (act) act.style.display = 'none';
    const cut = computeCutoff(mode, dFrom, dTo);
    if (!cut) { if (prog) prog.textContent = (mode === 'custom' && !dFrom) ? 'Isi tanggal "Dari" dulu ya.' : 'Gagal hitung rentang.'; reset(runBtn); running = false; return null; }
    const smartNoteHTML = cut.smartNote ? `<div style="font-size:11.5px;color:var(--spx-text-sec);background:var(--spx-bg-sec);border:1px dashed var(--spx-border);padding:6px 9px;border-radius:6px;margin-bottom:6px">💡 ${cut.smartNote}</div>` : '';
    if (prog) prog.innerHTML = `${smartNoteHTML}<div style="height:6px;background:#EAEEF3;border-radius:3px;overflow:hidden;margin-bottom:6px"><div style="height:100%;background:#14B8A6;width:0%;transition:width 0.3s"></div></div><div>Mulai scroll…</div>`;
    let posts = [];
    try {
      posts = await scrapeLoop(cut.from, cut.toEnd, (n, o) => {
        if (prog) {
          let pct = 0;
          if (o && cut.from) { const tot = startedAt - cut.from.getTime(); const cur = startedAt - o.getTime(); if (tot > 0) pct = Math.max(5, Math.min(100, Math.round((cur / tot) * 100))); }
          prog.innerHTML = `${smartNoteHTML}<div style="height:6px;background:#EAEEF3;border-radius:3px;overflow:hidden;margin-bottom:6px"><div style="height:100%;background:#14B8A6;width:${pct}%;transition:width 0.3s"></div></div><div>Scroll… <b>${n}</b> post, sampai ${o ? fmt(o) : '…'}${stopFlag ? ' (stop…)' : ''}</div>`;
        }
      });
      if (!posts.length) { lastResult = null; if (prog) prog.textContent = mode === 'today' ? 'Belum ada post hari ini (WIB). Coba "2 hari" / rentang tanggal.' : 'Tidak ada post di rentang ini.'; }
      else { lastResult = { posts, sym, smartNote: cut.smartNote }; renderOut(posts, sym); if (prog) prog.textContent = ''; }
    } catch (e) { lastErr = e.message; if (prog) prog.textContent = 'Error: ' + e.message; }
    finally { reset(runBtn); running = false; window.scrollTo(0, 0); }
    return posts;
  }
  function reset(runBtn) { if (runBtn) { runBtn.textContent = 'Mulai Scrape 🚀'; runBtn.classList.remove('stop'); } }

  function renderOut(posts, sym) {
    const out = $id('spx-out'); if (!out) return;
    const s = sentimentStats(posts, hideNoise), v = velocity(posts), st = topStats(posts), tc = typeCounts(posts);
    store.set(`hist_${sym}`, { bull: s.pct.bull, bear: s.pct.bear });
    const pd = readPriceData();
    const priceEl = $id('spx-price');
    if (priceEl) priceEl.textContent = pd ? `Rp${pd.price}` : '';
    
    const preds = posts.filter(p => p.pred);
    const seg = (w, c) => w > 0 ? `<i style="width:${w}%;background:${c}"></i>` : '';
    const validTc = Object.entries(tc).filter(([k]) => !['crosstag', 'news', 'insider', 'laporan', 'prediksi-bull', 'prediksi-bear'].includes(k));
    const chips = validTc.sort((a, b) => b[1] - a[1]).map(([k, n]) => `<span class="spx-chip">${TYPE_LABEL[k] || k} <b class="mono">${n}</b></span>`).join('');
    
    let predHTML = '';
    if (preds.length) {
      const pBull = preds.filter(p => p.type === 'prediksi-bull').length;
      const pBear = preds.filter(p => p.type === 'prediksi-bear').length;
      const pTotal = pBull + pBear || 1;
      const pcBull = Math.round(pBull / pTotal * 100);
      const pcBear = Math.round(pBear / pTotal * 100);
      predHTML = `<div class="spx-card"><h4>Prediksi (${preds.length})</h4><div class="spx-senti">${seg(pcBull, '#10B981')}${seg(pcBear, '#EF4444')}</div><div class="spx-kv" style="margin-bottom:8px"><b class="mono" style="color:#10B981">${pBull}</b> bullish • <b class="mono" style="color:#EF4444">${pBear}</b> bearish</div><div class="spx-kv">Target Bullish: <span class="mono" style="color:#10B981;font-weight:700">${formatTargets(preds, 'prediksi-bull')}</span><br>Target Bearish: <span class="mono" style="color:#EF4444;font-weight:700">${formatTargets(preds, 'prediksi-bear')}</span></div></div>`;
    }

    const moodBadge = (stt) => {
      if (stt.pct.bull >= 65 && stt.pct.promo >= 20) {
        return `<span style="font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;background:rgba(239,68,68,0.12);color:#EF4444;border:1px solid rgba(239,68,68,0.25);margin-left:auto">⚠️ Rawan Pom-pom</span>`;
      }
      if (stt.pct.bull >= 55) {
        return `<span style="font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;background:rgba(16,185,129,0.12);color:#10B981;border:1px solid rgba(16,185,129,0.25);margin-left:auto">🟢 Dominan Bull</span>`;
      }
      if (stt.pct.bear >= 45) {
        return `<span style="font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;background:rgba(239,68,68,0.12);color:#EF4444;border:1px solid rgba(239,68,68,0.25);margin-left:auto">🔴 Tekanan Jual</span>`;
      }
      return `<span style="font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:10px;background:rgba(148,163,184,0.12);color:var(--spx-text-muted);border:1px solid rgba(148,163,184,0.25);margin-left:auto">⚪ Sentimen Netral</span>`;
    };

    const largeWarning = posts.length > 500
      ? `<div style="font-size:11.5px;color:#B45309;background:#FEF3C7;border:1px solid #FDE68A;padding:7px 10px;border-radius:8px;margin-bottom:8px;line-height:1.4">💡 <b>Tips AI:</b> ${posts.length} post lumayan panjang. Jika ditempel ke ChatGPT/Claude gratis dan ditolak, gunakan rentang 'Hari ini' atau '3 Hari'.</div>`
      : '';

    const smartFallbackHTML = (lastResult && lastResult.smartNote)
      ? `<div style="font-size:11.5px;color:var(--spx-primary);background:var(--spx-btn-sec-bg);border:1px solid rgba(16,185,129,0.25);padding:6px 9px;border-radius:6px;margin-bottom:8px">💡 ${lastResult.smartNote}</div>`
      : '';

    out.style.display = 'block';
    out.innerHTML =
      smartFallbackHTML +
      largeWarning +
      `<div class="spx-card"><h4>Ringkasan</h4><div class="spx-kv"><b class="mono spx-big">${posts.length}</b> post • <b class="mono spx-big">${st.users}</b> user<br>${fmt(posts[posts.length - 1].d)} - ${fmt(posts[0].d)}</div><div style="margin-top:4px">${chips}</div></div>` +
      `<div class="spx-card"><div style="display:flex;align-items:center;margin-bottom:8px"><h4 style="margin:0">Sentimen ${hideNoise ? 'Organik ' : ''}(${s.n} post)</h4>${moodBadge(s)}</div><div style="display:flex;justify-content:flex-end;margin-bottom:6px"><button id="spx-toggle-noise" class="spx-btn sec-alt" style="margin-top:0;padding:3px 8px;font-size:11px;font-weight:700;border-radius:6px;cursor:pointer;background:${hideNoise ? 'var(--spx-primary)' : 'var(--spx-bg-alt)'};color:${hideNoise ? '#fff' : 'var(--spx-text-sec)'}">${hideNoise ? '🛡️ Filter Noise: AKTIF' : '🛡️ Filter Noise: NONAKTIF'}</button></div><div class="spx-senti">${seg(s.pct.bull, '#10B981')}${seg(s.pct.bear, '#EF4444')}${seg(s.pct.net + s.pct.promo, '#E2E8F0')}</div><div class="spx-kv"><b class="mono" style="color:#10B981">${s.pct.bull}%</b> bull • <b class="mono" style="color:#EF4444">${s.pct.bear}%</b> bear • <b class="mono">${s.pct.net + s.pct.promo}%</b> netral</div>${v.delta != null ? `<div class="spx-kv"><b>Velocity:</b> ${v.delta >= 0 ? '📈 +' : '📉 '}${v.delta}% post vs hari sebelumnya</div>` : ''}${renderVelocityChart(posts)}</div>` +
      predHTML +
      `<div class="spx-card"><h4>Siapa</h4><div class="spx-kv"><b>Top poster:</b> ${st.top.slice(0, 5).map(t => t[0] + ' (' + t[1] + ')').join(', ')}</div></div>`;
    
    const toggleNoiseBtn = $id('spx-toggle-noise');
    if (toggleNoiseBtn) {
      toggleNoiseBtn.onclick = () => {
        hideNoise = !hideNoise;
        renderOut(lastResult.posts, lastResult.sym);
      };
    }

    const act = $id('spx-actions'); if (act) act.style.display = 'flex';
  }

  /* ================= panduan ringkas (tab) ================= */
  function HELP_HTML() {
    return `
    <p class="q">Gimana cara kerjanya?</p>
    <p>Alat ini membaca postingan menggunakan <b>kamus kata</b>, bukan sistem AI yang berat.</p>
    <p>Sentimen (optimis/pesimis) hanya dihitung dari postingan diskusi murni. Kalau ada post yang isinya sekadar promosi grup atau ajakan, akan otomatis <b>diabaikan</b>.</p>
    <p>Sedangkan fitur <b>Velocity</b> berfungsi memantau lonjakan keramaian postingan hari ini dibanding hari-hari sebelumnya.</p>
    <p class="q">Post apa saja yang dihitung?</p>
    <p>Sentimen murni dari post <b>Diskusi</b>. Berita, info insider, laporan, prediksi, polling, dan chart dipisah.</p>
    <p class="q">Ada kendala?</p>
    <p>Coba muat ulang halaman. Jika masih error, salin log diagnostik ke Telegram.</p>
    <div class="spx-2" style="margin-top:12px;margin-bottom:8px">
      <button class="spx-btn sec" id="spx-help-diag" style="margin-top:0">📋 Salin diagnostik</button>
      <a href="https://t.me/lotmetrik" target="_blank" style="text-decoration:none;display:block;flex:1"><button class="spx-btn sec-alt" style="margin-top:0;height:100%;width:100%">💬 Kontak</button></a>
    </div>
    <div class="spx-disclaimer">100% Lokal (Tanpa Server) • Bukan saran investasi<br>Tidak terafiliasi dengan Stockbit.</div>`;
  }

  /* ================= boot (SPA-aware) ================= */
  async function boot() { if (/\/symbol\//.test(location.pathname)) { await mount(); } }
  let lastPath = location.pathname;
  setInterval(() => {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      if (running) stopFlag = true;
      lastResult = null;
      const o = $id('spx-out'); if (o) { o.style.display = 'none'; o.innerHTML = ''; }
      const a = $id('spx-actions'); if (a) a.style.display = 'none';
      const p = $id('spx-prog'); if (p) p.textContent = '';
      boot();
    }
    const s = $id('spx-sym'); if (s) s.textContent = '$' + symbol();
  }, 1500);
  const iv = setInterval(() => { if (document.body) { clearInterval(iv); boot(); } }, 400);
})();
