# ◆ Stream Scraper — Chrome Extension (MV3) v2.14.0

Ekstensi browser Chrome untuk analisa sentimen ritel di Stockbit Stream secara **real-time**, cepat, dan bersih. **Tanpa Tampermonkey.**

> **Versi extension ini yang di-maintain aktif.** 100% fokus pada *on-demand real-time scraping* saat Anda memantau emiten.

## 🌟 Baru di v2.14.0
- 🚀 **Tombol 1-Klik Buka AI**: Tombol `Buka AI 🚀` otomatis menyalin data obrolan format AI dan langsung membuka tab ChatGPT baru. Tinggal `Ctrl+V` & Enter!
- 🛡️ **Filter Noise Cepat di Bar UI**: Tombol toggle `🛡️ Filter Noise` langsung di atas bar sentimen. Sekali klik, persentase Bull/Bear langsung menghitung ulang dari post organik murni (bebas spam & promo).
- 🕒 **Indikator Sesi Bursa IDX**: Header panel menampilkan status sesi bursa real-time (`🟢 Sesi 1`, `⏸️ Istirahat`, `🟢 Sesi 2`, `🟠 Tutup Sesi`, `🔴 Bursa Tutup`).
- 💡 **Smart Fallback Weekend & Senin Pagi**: Otomatis mendeteksi jika bursa tutup (Sabtu/Minggu/Senin pra-bursa <09:00 WIB) dan memuat data sejak penutupan bursa Jumat lalu (anti 0 post).
- 🌐 **Kebal Multi-Bahasa Tanggal**: Parsing tanggal mendukung bulan Bahasa Indonesia (`Agu`, `Mei`, `Okt`, `Des`) dan Inggris (`Aug`, `May`, `Oct`, `Dec`).

## Riwayat Versi
- **v2.13.0**: Hapus scheduler/timer background, fokus real-time scraping, pangkas izin ke storage-only.
- **v2.12.0**: Penambahan badge status visual sentimen dinamis & kontrol jeda jadwal.
- **v2.11.2**: Perombakan performa scroll dengan `WeakSet` + icon SVG & force-stop wheel listener.
- **v2.5.0**: Fix scroll quote lama, kalender WIB 00:00, abaikan cross-tag, 1 tombol salin AI.
- **v2.2.0**: Kategorisasi tipe post (Diskusi/Chart/News/Insider/Laporan/Prediksi/Poll), design system Lotmetrik, tab panduan & salin diagnostik.

## 📁 Isi folder
```
extension/
  manifest.json     ← identitas extension (MV3, permission minimal: storage)
  background.js     ← service worker minimal (shortcut klik icon)
  content.js        ← panel UI + engine scraping real-time
  icons/            ← icon 16/48/128
```

## 🧩 Cara pasang (Load unpacked — buat pemakaian sendiri)

1. Buka Chrome → ketik di address bar: `chrome://extensions` → Enter.
2. Nyalakan **Developer mode** (toggle kanan atas).
3. Klik **Load unpacked** → pilih folder `extension` ini → Open.
4. Selesai. Buka `stockbit.com/symbol/ANTM` (pastikan sudah login) → panel **Stockbit Stream Scraper** muncul di kanan atas layar.

> 💡 **Tips Penggunaan**: Cukup klik tombol **Mulai Scrape 🚀**. Ekstensi akan otomatis scroll beberapa detik, membaca postingan, dan menyajikan ringkasan mood ritel, chart kepadatan trafik, dan target harga. Lalu klik **Salin** untuk di-paste ke ChatGPT/Claude dengan prompt Kit Sentimen Ritel.

## 🏪 Kalau mau publish ke Chrome Web Store (baca dulu, penting)

Secara teknis paket ini siap (manifest valid, sudah lolos `--pack-extension`).
Tapi dari **riset validasi kita sendiri**, publish PUBLIK berisiko:
1. **ToS Stockbit melarang scraping & pemakaian komersial** — listing publik dengan
   kata "Scraper" = ngundang komplain → takedown. Kalau tetap mau, pertimbangkan
   rename (mis. "Stream Mood untuk Stockbit") dan **publish UNLISTED** (nggak muncul
   di pencarian; link dibagi manual — cocok buat model freebie).
2. **Wajib privacy policy** (halaman 1 lembar, bisa di lotmetrik.my.id): nyatakan semua
   proses 100% lokal di perangkat, nggak ada data dikirim ke server mana pun, nggak ada
   analytics. Di dashboard CWS deklarasikan kategori "website content" + Limited Use.
3. Biaya developer $5 sekali + proses review beberapa hari.
4. Justifikasi permission (diminta saat submit): `storage` = simpan setting tema & posisi panel UI; host stockbit.com = membaca stream emiten yang sedang aktif dibuka user.

**Rekomendasi:** buat dipakai sendiri → load unpacked ini. Buat freebie ke orang lain → userscript Tampermonkey atau share folder zip extension. CWS unlisted = opsi kalau serius.

## ⚠️ Batasan jujur
- Kalau pasang extension INI **dan** userscript bersamaan: panel cuma muncul satu (anti-dobel), tapi sebaiknya pasang extension ini saja.
- Auto-sentimen bawaan = kamus kata (kasar). Analisis mendalam & komprehensif → gunakan tombol **Salin** + prompt di `../Kit-Sentimen-Ritel.md`.

*v2.13.0 — Penghapusan scheduler/timer background, pemangkasan permission ke storage-only, optimasi performa WeakSet, perbaikan scroll & auto-date WIB.*
